Building Encocoin
=============

See doc/build-*.md for instructions on building the various
elements of the Encocoin Core reference implementation of Encocoin.
